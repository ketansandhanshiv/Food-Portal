<?php

$m = new MongoClient(); // connect
$db = $m->selectDB("ketan");

?>


<?php

$db->command(array("logout" => 1));

?>
