
<?php

include "../CrimeDBMS/html/head.html";

echo "<div id=\"logindiv\">";               // for adding css properties

session_start();              // session is used to maintain the variables and helps them to pass between files.

echo '<div id="logcont">';

if (isset($_POST['usrname'])&&isset($_POST['paswrd']))
{

    $password = $_POST['paswrd'];
    $username = $_POST['usrname'];
    
    $_SESSION['username'] = $username;      // creating session variable for username. this can be accessed by all files till session is on
    $_SESSION['password'] = $password;
    
	if (!empty($acc)&&!empty($username)&&!empty($password)&&!empty($new))
    {
        $connection = new MongoClient();                        // connects to localhost:27017
        $db = $connection->cdbms;                               // getting or creating a database
        $collection = $db->login;                               // creating a collection 'login'
                                                                // other way is $collection = $connection->cdms->login
        
        if ($new == 'new')              // check if account is to be created -- else login into an existing account
        {
                     
            if ( !empty($cursor) )      // if ther is admin account then enter username and password of the admin to create new account. This is required for both admin and user. Passed onto the authenticate.php
            {
                echo 'Enter Username and Password of the current admin to create new account';
                echo "<form action=\"authenticate.php\" method=\"POST\">
                            Username: <input type=\"text\" name=\"admusr\"><br><br>
                            Password: <input type=\"password\" name=\"admpwd\"><br><br>
                            <input type=\"submit\" value=\"Create\">
                    </form>";
            }
            elseif ( empty($cursor) && $acc == 'admin')         // if no admin is ther in database and seleted account type is admin then insert it
            {
                $doc = array(                                   // creating array of document to be inserted
                            "acc_type" => $acc,
                            "username" => $username,
                            "password" => md5($password)        // md5 encoding for security
                        );
                $collection->insert( $doc );                    // inserting the document
//                header('Location: admin.php');
                echo '<p class="success">Admin account for '.$username.' created successfully.</p>';           // account created successfully
                header( "refresh:3;url=adminpage.php" );              // redirect to admin page after 3 seconds 
            }
            else                            // user account cannot be created if no admin account exists in the database
                echo '<p class="error">User account cannot be created, there should be at least one admin account in the database.<p>';
        }
        elseif ($new == 'exist')            // if want to login into existing account
        {
            $doc = $collection->findOne(array('username' => $username));    //check if username exists
            if (empty($doc) || $doc['password'] != md5($password))               // verify password
            {
                echo '<p class="error">Wrong Username or Password</p>';
            }
            elseif (($doc['acc_type'] != $acc && $doc['username'] == $username))  // check if selected account type matches with that of the user in database
            {
                echo '<p class="error">Wrong Username or Account type</p>';
                echo $doc['username'].' '.$doc['acc_type'];
            }
            else                    // login and redirect to respective admin or user page after 3 seconds
            {
                echo '<p class="success">Login successful. Redirecting...</p>';
                if ($acc == 'admin')
                        header( "refresh:3;url=adminpage.php" );
            }
        }
    }
    else
        echo '<p class="error">Enter in all the fields</p>';
}
else
    echo '<p class="error">Enter in all the fields</p>';

echo '</div>';
echo '</div>';

include "html/footer.html";
?>