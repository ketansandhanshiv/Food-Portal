<?php

$connection = new MongoClient();
$db = $connection->cdbms;
$collection = $db->login->remove();

?>