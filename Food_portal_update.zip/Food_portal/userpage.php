<?php

include "../CrimeDBMS/html/head.html";

session_start();
$username = $_SESSION['username'];


?>