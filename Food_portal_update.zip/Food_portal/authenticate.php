<?php


session_start();                        // start of session to maintain the variables even after closing file

$uname = $_SESSION['username'];
$pword = $_SESSION['password'];

echo '<div id="logcont">';

if (isset($_POST['admusr'])&&isset($_POST['admpwd']))
{   
    $password = $_POST['admpwd'];
    $username = $_POST['admusr'];
    
	if (!empty($username)&&!empty($password))
    {
        $connection = new MongoClient();
        $db = $connection->cdbms;
        $collection = $db->login;
        
        $doc = $collection->findOne(array('username' => $username));
        if (empty($doc))                                // to check whether admin exists
        {
            echo "Admin $username does not exists";
        }
        elseif ($doc['password'] != md5($password) || $doc['acc_type'] != 'admin')          // to check password for authentication
        {
            echo "Wrong Username or Password";
        }
        else
        {
            $doc = $collection->findOne(array('username' => $_SESSION['username']));             // checking if user already exists
            if(!empty($doc))
                echo '<p class="error">Username already exists, Please enter another username</p>';

            else
            {
                $doc = array(                                   // creating array of document to be inserted
                    "username" => $uname,
                    "password" => md5($pword)         // md5 encoding for security
                    );
                $collection->insert( $doc );                    // inserting the document
                echo '<p class="success">New '.' account '.$_SESSION['username'].' created successfully. Redirecting...</p>';
                         // check account type and redirect to respective admin or user page after 3 secs
              header( "refresh:3;url=adminpage.php" );

            }
        }
    }
    else
        echo '<p class="error">Enter in all the fields</p>';
}
else
    echo '<p class="error">Enter in all the fields</p>';

echo '</div>';              // closing divs
echo '</div>';

include "../CrimeDBMS/html/footer.html";
?>