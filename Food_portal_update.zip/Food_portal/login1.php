<?php

session_start();              // session is used to maintain the variables and helps them to pass between files.

echo '<div id="logcont">';
$password = $_POST['paswrd'];
    $username = $_POST['usrname'];
    
    $_SESSION['username'] = $username;      // creating session variable for username. this can be accessed by all files till session is on
    $_SESSION['password'] = $password;
 $connection = new MongoClient();                        // connects to localhost:27017
        $db = $connection->cdbms;                               // getting or creating a database
        $collection = $db->login;                               // creating a collection 'login'
                                                                // other way is $collection = $connection->cdms->login
if ($new == 'new')   
{
echo 'Enter Username and Password of the current admin to create new account';
                echo "<form action=\"authenticate1.php\" method=\"POST\">
                            Username: <input type=\"text\" name=\"admusr\"><br><br>
                            Password: <input type=\"password\" name=\"admpwd\"><br><br>        
                                </form>";



$doc = array(                                   // creating array of document to be inserted
                            "username" => $username,
                            "password" => md5($password)        // md5 encoding for security
                        );
                $collection->insert( $doc );                    // inserting the document
//                header('Location: admin.php');
                echo '<p class="success">Admin account for '.$username.' created successfully.</p>';           // account created successfully
                header( "refresh:3;url=adminpage.php" );          
                echo '<p class="error">Enter in all the fields</p>';
}

echo '</div>';
echo '</div>';

include "html/footer.html";
?>