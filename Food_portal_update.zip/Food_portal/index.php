<?php

//include contents of the following files in sequence
include "html/head.html";

include "html/login.html";

include "html/footer.html";

?>