<?php


include "../CrimeDBMS/html/insert.html";
?>