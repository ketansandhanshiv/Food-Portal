<?php

include "../food_portal3/html/head.html";

echo "<div id=\"logindiv\">";           // for adding css properties

session_start();                        // start of session to maintain the variables even after closing file

echo '<div id="logcont">';

if (isset($_POST['admusr'])&&isset($_POST['admpwd']))
{   
    $password = $_POST['admpwd'];
    $username = $_POST['admusr'];
    $account = $_SESSION['acctype'];
    $newname = $_SESSION['username'];
    $newpass = $_SESSION['password'];
    
	if (!empty($username)&&!empty($password))
    {
        $connection = new MongoClient();
        $db = $connection->mdbms;
        $collection = $db->login;
        
        $doc = $collection->findOne(array('username' => $username));
        if (empty($doc))                                // to check whether admin exists
        {
            echo "Admin $username does not exists";
            session_destroy();
            header("refresh:3;url=index.php");
        }
        elseif ($doc['password'] != md5($password) || $doc['acc_type'] != 'admin')          // to check password for authentication
        {
            echo "Wrong Account Type or Password";
            session_destroy();
            header("refresh:3;url=index.php");
        }
        else
        {
            $doc = $collection->findOne(array('username' => $_SESSION['username']));             // checking if user already exists
            if(!empty($doc))
            {
                echo '<p class="error">Username already exists, Please enter another username</p>';
                session_destroy();
                header("refresh:3;url=index.php");
            }

            else
            {   
                $doc = array(                                   // creating array of document to be inserted
                    "acc_type" => $account,
                    "username" => $newname,
                    "password" => md5($newpass)         // md5 encoding for security
                    );
                $collection->insert( $doc );                    // inserting the document
                
                $_SESSION['username'] = $newname;
                $_SESSION['password'] = $newpass;
                $_SESSION['acctype'] = $account;
                
                echo '<p class="success">New Admin account for '.$_SESSION['username'].' created successfully. Redirecting...</p>';
                // check account type and redirect to respective admin or user page after 3 secs
                header( "refresh:3;url=adminpage.php" );
            }
        }
    }
    else
    {
        echo '<p class="error">Entermin all the fields</p>';
        session_destroy();
        header("refresh:3;url=index.php");
    }
}
else
{
    echo '<p class="error">Enter in all the fields</p>';
    session_destroy();
    header("refresh:3;url=index.php");
}

echo '</div>';              // closing divs
echo '</div>';

include "../food_portal3/html/footer.html";
?>