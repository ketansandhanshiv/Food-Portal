<?php

session_start();
//$username = $_SESSION['username'];
$_SESSION['hotelid'] = $_POST['hotelid'];
$hotelid = $_SESSION['hotelid'];
//$username = $_SESSION['username'];
//if (empty($username))
//{
//    include "../food_portal3/html/nocontinue.html";
//    include "../food_portal3/html/footer.html";
//}

//else
//{
    $connection = new MongoClient();
    $db = $connection->mdbms;
    $collection = $db->hotel;
    $doc = $collection->findOne(array('hotelid' => $_POST['hotelid']));
    if ( empty($doc) )
    {
        include "../food_portal3/html/notfound.html";
        include "../food_portal3/html/footer.html";
    }
    else
    {
        $connection = new MongoClient();
        $db = $connection->mdbms;
        $hot_coll = $db->hotel;
        $fac_coll = $db->facilities;
        $loc_coll = $db->location;
        $food_coll = $db->food;

        $hot_coll->remove(array('hotelid' => $hotelid));
        $fac_coll->remove(array('ffood' => $ffood));
        $loc_coll->remove(array('state' => $state));
        $food_coll->remove(array('fstart' => $fstart));
        
        //$location = '../food_portal1/images/';
        //if($img_type == 'image/gif')
        //    $ext = '.gif';
        //elseif($img_type == 'image/jpg' || $img_type == 'image/jpeg')
        //    $ext = '.jpg';
        //elseif($img_type == 'image/png')
        //    $ext = '.png';
        //$img_name = "$location$hotelid$ext";
        //unlink(@$img_name);

        include "../food_portal3/html/deleted.html";
        include "../food_portal3/html/footer.html";
    }
//}
?>