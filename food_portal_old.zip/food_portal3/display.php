<?php

session_start();
$username = $_SESSION['username'];

include "../food_portal3/html/display.html";
?>