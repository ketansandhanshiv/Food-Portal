<?php

include "../food_portal3/html/head.html";

echo "<div id=\"logindiv\">";               // for adding css properties

session_start();              // session is used to maintain the variables and helps them to pass between files.

echo '<div id="logcont">';

if (isset($_POST['usrname'])&&isset($_POST['paswrd'])&&isset($_POST['acctype'])&&isset($_POST['newacc']))
{
    $new = $_POST['newacc'];
    $acc = $_POST['acctype'];
    $password = $_POST['paswrd'];
    $username = $_POST['usrname'];
    
    
	if (!empty($acc)&&!empty($username)&&!empty($password)&&!empty($new))
    {
        $connection = new MongoClient();                        // connects to localhost:27017
        $db = $connection->mdbms;                               // getting or creating a database
        $collection = $db->login;                               // creating a collection 'login'
                                                                // other way is $collection = $connection->cdms->login
        
        if ($new == 'new')              // check if account is to be created -- else login into an existing account
        {
            $query = array( 'acc_type' => 'admin' );
            $cursor = $collection->findone( $query );   // check whether at least one admin account exists
            
            if ( !empty($cursor) && $acc == 'admin')      // if ther is admin account then enter username and password of the admin to create new account. This is required for admin. Passed onto the authenticate.php
            {
                $_SESSION['username'] = $username;
                $_SESSION['password'] = $password;
                $_SESSION['acctype'] = $acc;
                echo 'Enter Username and Password of the current admin to create new account';
                echo "<form action=\"authenticate.php\" method=\"POST\">
                            Username: <input type=\"text\" name=\"admusr\"><br><br>
                            Password: <input type=\"password\" name=\"admpwd\"><br><br>
                            <input type=\"submit\" value=\"Create\">
                    </form>";
            }
            elseif ( !empty($cursor) && $acc == 'user')
            {
                $doc = array(                                   // creating array of document to be inserted
                            "acc_type" => $acc,
                            "username" => $username,
                            "password" => md5($password)        // md5 encoding for security
                        );
                $collection->insert( $doc );                    // inserting the document
                
                $_SESSION['username'] = $username;      // creating session variable for username. this can be accessed by all files till session is on
                $_SESSION['password'] = $password;
                $_SESSION['acctype'] = $acc;
                
                echo '<p class="success">User account for '.$username.' created successfully.</p>';           // account created successfully
                header( "refresh:3;url=userpage.php" );
            }
            elseif ( empty($cursor) && $acc == 'admin')         // if no admin is ther in database and seleted account type is admin then insert it
            {
                $doc = array(                                   // creating array of document to be inserted
                            "acc_type" => $acc,
                            "username" => $username,
                            "password" => md5($password)        // md5 encoding for security
                        );
                $collection->insert( $doc );                    // inserting the document
                
                $_SESSION['username'] = $username;      // creating session variable for username. this can be accessed by all files till session is on
                $_SESSION['password'] = $password;
                $_SESSION['acctype'] = $acc;
                
                echo '<p class="success">Admin account for '.$username.' created successfully.</p>';           // account created successfully
                header( "refresh:3;url=adminpage.php" );              // redirect to admin page after 3 seconds 
            }
            else                            // user account cannot be created if no admin account exists in the database
            {
                echo '<p class="error">User account cannot be created, there should be at least one admin account in the database.<p>';
                session_destroy();
                header("refresh:3;url=index.php");
            }
        }
        elseif ($new == 'exist')            // if want to login into existing account
        {
            $doc = $collection->findOne(array('username' => $username));    //check if username exists
            if (empty($doc) || $doc['password'] != md5($password))               // verify password
            {
                echo '<p class="error">Access Denied</p>';
                session_destroy();
                header("refresh:3;url=index.php");               
            }
            elseif (($doc['acc_type'] != $acc && $doc['username'] == $username))  // check if selected account type matches with that of the user in database
            {
                echo '<p class="error">Access Denied</p>';
                session_destroy();
                header("refresh:3;url=index.php");
            }
            else                    // login and redirect to respective admin or user page after 3 seconds
            {
                $_SESSION['username'] = $username;      // creating session variable for username. this can be accessed by all files till session is on
                $_SESSION['password'] = $password;
                $_SESSION['acctype'] = $acc;

                echo '<p class="success">Login successful. Redirecting...</p>';
                if ($acc == 'admin')
                        header( "refresh:3;url=adminpage.php" );
                else
                    header( "refresh:3;url=userpage.php" );
            }
        }
    }
    else
    {
        echo '<p class="error">Enter in all the fields...</p>';
        session_destroy();
        header("refresh:3;url=index.php");
    }
}
else
{
    echo '<p class="error">Enter in all the fields...</p>';
    session_destroy();
    header("refresh:3;url=index.php");
}

echo '</div>';
echo '</div>';

include "html/footer.html";
?>