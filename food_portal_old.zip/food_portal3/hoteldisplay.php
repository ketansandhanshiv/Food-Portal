<?php

session_start();
$username = $_SESSION['username'];

    $hotelid = $_POST['hotelid'];
    $hname = $_POST['hname'];
    $connection = new MongoClient();
    $db = $connection->mdbms;
    $collection = $db->hotel;

if(!empty($hotelid))
    {
        $doc = $collection->findOne(array('hotelid' => $hotelid));
        if (empty($doc) )
        {
            include "../food_portal3/html/notfound.html";
            goto end;
        }
        else
        {
            include "../food_portal3/html/head.html";
            $criteria = array('hotelid' => $hotelid);
            $byID = 1;
        }
    }
    else
    {        

            include "../food_portal3/html/notfound.html";
            goto end;
           
                $criteria = array('hname' => $hname);
                $byID = 0;
            
    }
    $hot_coll = $db->hotel;                               // creating colections for each entity
    $fac_coll = $db->facilities;
    $loc_coll = $db->location;
    $food_coll = $db->food;

        
    $cursor = $hot_coll->find($criteria);
    $cursor1 = $fac_coll->find($criteria);
    $cursor2 = $loc_coll->find($criteria);
    $cursor3 = $food_coll->find($criteria);
    
    echo "<div id=\"insertdiv\">";           // for adding css properties    
    echo '<div id="inscont">';
    echo '<div id="dispdiv">';
    if($byID == 1)
    {
        echo "<pre>Search Criteria: hotel ID = <b>$hotelid</b></pre>";
        echo '<table>';
        echo '<tr><td><b>Hotel Details:-</b></td></tr>  <br>';
      
        foreach ($cursor as $obj) 
        {
            echo '<tr><td><b>Hotel name</b></td><td>' . $obj['hname'] . '</td></tr>';
            echo '<tr><td><b>Hotel description</b></td><td>' . $obj['hdesc'] . '</td></tr>';
            echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';
        }
        echo '<tr><td><b>Facilities Details:-</b></td></tr>  <br>';
        foreach ($cursor1 as $obj) 
        {

            echo '<tr><td><b>Family food</b></td><td>' . $obj['ffood'] . '</td></tr>';
            echo '<tr><td><b>Indian food</b></td><td>' . $obj['ifood'] . '</td></tr>';
            echo '<tr><td><b>Chinese food</b></td><td>' . $obj['cfood'] . '</td></tr>';
            echo '<tr><td><b>Fast food</b></td><td>' . $obj['fafood'] . '</td></tr>';
            echo '<tr><td><b>Vegetarian</b></td><td>' . $obj['vege'] . '</td></tr>';
            echo '<tr><td><b>Non-vegetarian</b></td><td>' . $obj['nvege'] . '</td></tr>';
            echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';

        }
        echo '<tr><td><b>Location Details:-</b></td></tr>  <br>';
        foreach ($cursor2 as $obj) 
        {
            echo '<tr><td><b>State</b></td><td>' . $obj['state'] . '</td></tr>';
            echo '<tr><td><b>City</b></td><td>' . $obj['lcity'] . '</td></tr>';
            echo '<tr><td><b>Distance(from city)</b></td><td>' . $obj['ldist'] . '</td></tr>';
            echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';            
        }
        echo '<tr><td><b>Food Details:-</b></td></tr>  <br>';
        foreach ($cursor3 as $obj) 
        {
            echo '<tr><td><b>Starter</b></td><td>' . $obj['fstart'] . '</td></tr>';
            echo '<tr><td><b>Beverage</b></td><td>' . $obj['fbeverage'] . '</td></tr>';
            echo '<tr><td><b>Main-course</b></td><td>' . $obj['fmain'] . '</td></tr>';
            echo '<tr><td><b>Light-meals</b></td><td>' . $obj['flight'] . '</td></tr>';
            echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';
        }
        echo '</table>';
    }
    else
    {
        echo "<pre>Search Criteria: Hotel name = <b>$hname</b></pre>";
        $cursor = $hot_coll->find($criteria);
        $count = $hot_coll->count($criteria);
        echo "Records Found: $count<br><br>";
        echo '<table>';
        echo '<tr><td><b>Hotel Details</b></td></tr>';
        foreach ($cursor as $obj) 
        {
            echo '<tr><td><b>Hotel ID</b></td><td>' . $obj['hotelid'] . '</td></tr>';
            echo '<tr><td><b>Hotel name</b></td><td>' . $obj['hname'] . '</td></tr>';
            echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';            
        }
        echo '</table>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';

    end:
    include "../food_portal3/html/footer.html";
?>