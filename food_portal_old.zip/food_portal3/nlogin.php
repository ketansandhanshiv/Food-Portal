<?php

session_start();
$username = $_SESSION['username'];
include "../food_portal3/html/head.html";
include "../food_portal3/html/login.html";
?>