<?php
session_start();

include "../food_portal3/html/head.html";

    $hotelid = $_POST['hotelid'];
    $hname = $_POST['hname'];
    $hdesc = $_POST['hdesc'];

    $ffood = $_POST['ffood'];
    $ifood = $_POST['ifood'];
    $cfood = $_POST['cfood'];
    $fafood = $_POST['fafood'];
    $vege = $_POST['vege'];
    $nvege = $_POST['nvege'];

    $state = $_POST['state'];
    $lcity = $_POST['lcity'];
    $ldist = $_POST['ldist'];

    $fstart = $_POST['fstart'];
    $fbeverage = $_POST['fbeverage'];
    $fmain = $_POST['fmain'];
    $flight = $_POST['flight'];
//-------------------------------------------------------------
    if(trim(empty($_POST['hdesc'])))
    {
        $hdesc = 'N/A';
    }
    else
    {
        $hdesc = $_POST['hdesc'];
    }
//--------------------------------------------------------------
if(trim(empty($_POST['ldist'])))
    {
        $ldist = 'N/A';
    }
    else
    {
        $ldist = $_POST['ldist'];
    }
//--------------------------------------------------------------

   echo "<div id=\"insertdiv\">";         
   echo '<div id="inscont">';

    $connection = new MongoClient();                        // connects to localhost:27017
    $db = $connection->mdbms;                               // getting or creating a database
    $hot_coll = $db->hotel;                               // creating colections for each entity
    $fac_coll = $db->facilities;
    $loc_coll = $db->location;
    $food_coll = $db->food;
//----------------------------------------------------------------
// Creating array of document
    $hot_doc = array(                               
                        "hotelid" => $hotelid,
                        "hname" => $hname,
                        "hdesc" => $hdesc,
                    );
    $hot_coll->insert( $hot_doc );
    //---------------------------------
    $fac_doc = array(                         
                        "hotelid" => $hotelid,
                        "ffood" => $ffood,
                        "ifood" => $ifood,
                        "cfood" => $cfood,
                        "fafood" => $fafood,
                        "vege" => $vege,
                        "nvege" => $nvege,

                    );
    $fac_coll->insert( $fac_doc );
    //---------------------------------
    $loc_doc = array(                         
                        "hotelid" => $hotelid,
                        "state" => $state,
                        "lcity" => $lcity,
                        "ldist" => $ldist,
                    );
    $loc_coll->insert( $loc_doc );
    //----------------------------------
    $food_doc = array(                        
                        "hotelid" => $hotelid,
                        "fstart" => $fstart,
                        "fbeverage" => $fbeverage,
                        "fmain" => $fmain,
                        "flight" => $flight,
                    );
    $food_coll->insert( $food_doc );
    //----------------------------------
    
$criteria = array('hotelid' => $hotelid);

    $cursor = $hot_coll->find($criteria);
    $cursor1 = $fac_coll->find($criteria);
    $cursor2 = $loc_coll->find($criteria);
    $cursor3 = $food_coll->find($criteria);

// ----- Display first column------

    echo '<table>';
    // -----  Hotel Info -------
    echo '<tr><td><b>Hotel Info</b></td></tr>';
    foreach ($cursor as $obj) 
    {
        echo '<tr><td><b>Hotel Id</b></td><td>' . $obj['hotelid'] . '</td></tr>';
        echo '<tr><td><b>Hotel Name</b></td><td>' . $obj['hname'] . '</td></tr>';
        echo '<tr><td><b>Hotel Description</b></td><td>' . $obj['hdesc'] . '</td></tr>';
        
        echo '<tr><td></td></tr>';
    }
    //------ Facilities Provided By Hotel -----
    echo '<tr><td><b>Facilities</b></td></tr>';
    foreach ($cursor1 as $obj) 
    {
        $ff=  $obj['ffood'];
        $if=  $obj['ifood'];
        $cf=  $obj['cfood'];
        $fa=  $obj['fafood'];
        $v=  $obj['vege'];
        $nv=  $obj['nvege'];
        
        echo '<tr><td><b>Family Food</b></td><td>' . $obj['ffood'] . '</td></tr>';
        echo '<tr><td><b>Indian Food</b></td><td>' . $obj['ifood'] . '</td></tr>';
        echo '<tr><td><b>Chinese Food</b></td><td>' . $obj['cfood'] . '</td></tr>';
        echo '<tr><td><b>Fast Food</b></td><td>' . $obj['fafood'] . '</td></tr>';
        echo '<tr><td><b>Vegetarian</b></td><td>' . $obj['vege'] . '</td></tr>';
        echo '<tr><td><b>Non-Veg</b></td><td>' . $obj['nvege'] . '</td></tr>';

  /*      echo '<tr><td></td></tr>';
        if($ff==on)
        {
            echo '<tr><td><b>Family Food</b></td><td> YES </td></tr>';
        }
        elseif($ff!=on)
        {
            echo '<tr><td><b>Family Food</b></td><td>NO</td></tr>';
        }
        
        if($if==on)
        {
            echo '<tr><td><b>Indian Food</b></td><td> YES </td></tr>';
        }
        elseif($if!=on)
        {
            echo '<tr><td><b>Indian Food</b></td><td>NO</td></tr>';
        }
        
        if($cf==on)
        {
            echo '<tr><td><b>Chinese Food</b></td><td> YES </td></tr>';
        }
        elseif($cf!=on)
        {
            echo '<tr><td><b>Chinese Food</b></td><td>NO</td></tr>';
        }
        
        if($fa==on)
        {
            echo '<tr><td><b>Fast Food</b></td><td> YES </td></tr>';
        }
        elseif($fa!=on)
        {
            echo '<tr><td><b>Fast Food</b></td><td>NO</td></tr>';
        }
        
        if($v==on)
        {
            echo '<tr><td><b>Vegetarian Food</b></td><td> YES </td></tr>';
        }
        elseif($v!=on)
        {
            echo '<tr><td><b>Vegetarian Food</b></td><td>NO</td></tr>';
        }
        
        if($nv==on)
        {
            echo '<tr><td><b>Non-Vegetarian Food</b></td><td> YES </td></tr>';
        }
        elseif($nv!=on)
        {
            echo '<tr><td><b>Non-Vegetarian Food</b></td><td>NO</td></tr>';
        }
*/
    }
    
    // -----  Hotel Location  -------
    echo '<tr><td><b>Hotel Location</b></td></tr>';
    foreach ($cursor2 as $obj) 
    {
        echo '<tr><td><b>State</b></td><td>' . $obj['state'] . '</td></tr>';
        echo '<tr><td><b>City</b></td><td>' . $obj['lcity'] . '</td></tr>';
        echo '<tr><td><b>Distance</b></td><td>' . $obj['ldist'] . '</td></tr>';
        
        echo '<tr><td></td></tr>';
    }
    // -----  Hotel Food  -------
    echo '<tr><td><b>Hotel Food</b></td></tr>';
    foreach ($cursor3 as $obj) 
    {
        echo '<tr><td><b>Food Starter</b></td><td>' . $obj['fstart'] . '</td></tr>';
        echo '<tr><td><b>Beverages</b></td><td>' . $obj['fbeverage'] . '</td></tr>';
        echo '<tr><td><b>Main Course</b></td><td>' . $obj['fmain'] . '</td></tr>';
        echo '<tr><td><b>Light Meal</b></td><td>' . $obj['flight'] . '</td></tr>';
        
        echo '<tr><td></td></tr>';
    }
    echo '</table>';

    echo '</div>';              // closing divs
    echo '</div>';

    include "../food_portal3/html/footer.html";

?>