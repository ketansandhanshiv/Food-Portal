Only login section is created

Add your file in food_portal(root) folder or give proper path

URL for site is 'localhost/food_portal1'. index.php will open first, consisting of login page, login.html

To check all scenarios give inputs in following order:
1. create(new) 'user' account		- Fail
2. access(existing) 'user' acount	- Fail
3. access admin account			- Fail
4. create admin account			- Success
5. access admin account			- Success
6. create user account			- Success
7. access user account			- Success


Before opening site, start the apache server and mongoDB from AMPPS configuration

To delete all documents (accounts) goto 'localhost/delete.php'