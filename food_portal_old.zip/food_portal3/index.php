<?php


include "html/head.html";

include "html/login.html";

include "html/footer.html";

?>