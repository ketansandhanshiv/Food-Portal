<?php
session_start();
$username = $_SESSION['username'];
$acctype = $_SESSION['acctype'];
if (empty($username) || empty($acctype) || $acctype != 'user')
{
    echo "$username $acctype";
    include "../food_portal3/html/nocontinue.html";
    include "../food_portal3/html/footer.html";
}
else
{
    include "../food_portal3/html/userdisp.html";
}
?>