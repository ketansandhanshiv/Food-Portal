<?php

session_start();
$username = $_SESSION['username'];

if (empty($username))
{
    include "../food_portal3/html/nocontinue.html";
    include "../food_portal3/html/footer.html";
}
else
{    
    include "../food_portal3/html/head.html";
    
    echo "<div id=\"insertdiv\">";           // for adding css properties    
    echo '<div id="inscont">';

    echo '<div id="dispdiv">';

    $connection = new MongoClient();
    $db = $connection->mdbms;
    $collection = $db->hotel;
    $cursor = $collection->find();

    echo '<table>';
    echo '<tr><td><b>Hotel Details</b></td></tr>';
    foreach ($cursor as $obj) 
    {
        echo '<tr><td><b>Hotel ID-</b></td><td>' . $obj['hotelid'] . '</td></tr>';
        echo '<tr><td><b>Hotel name-</b></td><td>' . $obj['hname'] . '</td></tr>';
        echo '<tr><td><b>Hotel Description-</b></td><td>' . $obj['hdesc'] . '</td></tr>';
        echo '<tr><td>&nbsp;</td><td>&nbsp;</td></tr>';

    }
    echo '</table>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
  
    include "../food_portal3/html/footer.html";
}
?>