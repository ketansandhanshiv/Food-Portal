<?php

session_start();

$username = $_SESSION['username'];

    include "../food_portal3/html/head.html";
    
    $connection = new MongoClient();
    $db = $connection->mdbms;

    $hot_coll = $db->hotel;
    $fac_coll = $db->facilities;
    $loc_coll = $db->location;
    $food_coll = $db->food;

    $cursor = $hot_coll->find();
    $cursor1 = $fac_coll->find();
    $cursor2 = $loc_coll->find();
    $cursor3 = $food_coll->find();

    foreach ($cursor as $obj) 
    {
        $hotelid = $obj['hotelid'];
        $hname = $obj['hname'];
        $hdesc = $obj['hdesc'];
    }
    foreach ($cursor1 as $obj) 
    {
        $ffood = $obj['ffood'];
        $ifood = $obj['ifood'];
        $cfood = $obj['cfood'];
        $fafood = $obj['fafood'];
        $vege = $obj['vege'];
        $nvege = $obj['nvege'];
    }
    foreach ($cursor2 as $obj) 
    {
        $state = $obj['state'];
        $lcity = $obj['lcity'];
        $ldist = $obj['ldist'];
    }
    foreach ($cursor3 as $obj) 
    {
        $fstart = $obj['fstart'];
        $fbeverage = $obj['fbeverage'];
        $fmain = $obj['fmain'];
        $flight = $obj['flight'];
    }

include "../food_portal3/html/ninsert.html";

?>