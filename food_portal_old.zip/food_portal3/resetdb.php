<?php

session_start();

$username = $_SESSION['username'];

    $connection = new MongoClient();                        // connects to localhost:27017
    $db = $connection->mdbms;                               // getting or creating a database
    $hot_coll = $db->hotel;                               // creating colections for each entity
    $fac_coll = $db->facilities;
    $loc_coll = $db->location;
    $food_coll = $db->food;

    $hot_coll->remove();
    $fac_coll->remove();
    $loc_coll->remove();
    $food_coll->remove();

    include "../food_portal3/html/deleted.html";
    include "../food_portal3/html/footer.html";

?>